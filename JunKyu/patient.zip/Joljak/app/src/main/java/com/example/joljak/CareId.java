package com.example.joljak;

public class CareId {//보호자 인터페이스 정보+추가 필요
    public String CareId;
    public String Phone;
    CareId(String careId,String phone){
        this.CareId=careId;
        this.Phone=phone;
    }
    CareId(){

    }
}
