package com.example.joljak;

public class UserId {// 사용자 인터페이스 정보 ++ 추가 필요
    String name;
    String Address;
    UserId(String name,String Address){
        this.name=name;
        this.Address=Address;
    }
    UserId(){

    }
}
