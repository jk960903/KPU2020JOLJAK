package com.example.joljak;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class WalkRequest extends StringRequest {
    final static private String URL="";//주소가 들어가야함
    private Map<String,String> parameter;
    public WalkRequest(String day, Integer walkcount, Response.Listener<String> listener){
        super(Method.POST,URL,listener,null);
        parameter=new HashMap<>();
        parameter.put("day",day);
        parameter.put("walk",Integer.toString(walkcount));

    }
    @Override
    protected Map<String,String> getParams() throws AuthFailureError{
        return parameter;
    }

}
