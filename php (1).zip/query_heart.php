<?php  
error_reporting(E_ALL); 
ini_set('display_errors',1); 

include('dbcon.php');

   

//POST ���� �о�´�.
$data2=isset($_POST['data2']) ? $_POST['data2'] : '';
$android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");


if ($data2 != "" ){ 

    $sql="select * from heart";
    $stmt = $con->prepare($sql);
    $stmt->execute();
 
    if ($stmt->rowCount() == 0){

        echo "'";
        echo $p_name;
        echo "'�� ã�� �� �����ϴ�.";
    }
	else{

   		$data = array(); 

        while($row=$stmt->fetch(PDO::FETCH_ASSOC)){

        	extract($row);

            array_push($data, 
                  array('p_name'=>$row["p_name"],
                'p_heart'=>$row["p_heart"]
            ));
        }


        if (!$android) {
            echo "<pre>"; 
            print_r($data); 
            echo '</pre>';
        }else
        {
            header('Content-Type: application/json; charset=utf8');
            $json = json_encode(array("root"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
            echo $json;
        }
    }
}
else {
    echo "�ɹ� ";
}

?>



<?php

$android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");

if (!$android){
?>

<html>
   <body>
   
      <form action="<?php $_PHP_SELF ?>" method="POST">
         �ɹ�: <input type = "text" name = "heart" />
         <input type = "submit" />
      </form>
   
   </body>
</html>
<?php
}

   
?>