<?php
   $con = mysqli_connect("localhost", "root", "","Patient");

    mysqli_set_charset($con, "utf8");
    $p_name = $_POST["p_name"];
    $p_heart = $_POST["p_heart"];

    $statement = "INSERT INTO heart (p_name, p_heart) VALUES ('$p_name', '$p_heart')";
     
    if(mysqli_query($con, $statement)){
	echo '���ε�';
    } else{
	echo '���ε� ����';
    }
?>