<?php
   $con = mysqli_connect("localhost", "root", "","Patient");

    mysqli_set_charset($con, "utf8");
    $p_name = $_POST["p_name"];
    $p_address = $_POST["p_address"];
    $c_name = $_POST["c_name"];
    $c_phone = $_POST["c_phone"];

    $statement = "INSERT INTO demo (p_name, p_address, c_name, c_phone) VALUES ('$p_name', '$p_address', '$c_name', '$c_phone')";
     
    if(mysqli_query($con, $statement)){
	echo '�Է�';
    } else{
	echo '�Է� ����';
    }
?>