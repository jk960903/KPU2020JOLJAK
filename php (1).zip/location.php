<?php
   $con = mysqli_connect("localhost", "root", "","Patient");

    mysqli_set_charset($con, "utf8");
    $p_name = $_POST["p_name"];
    $p_latitude = $_POST["p_latitude"];
    $p_longitude = $_POST["p_longitude"];

    $statement = "INSERT INTO location (p_name, p_longitude, p_latitude) VALUES ('$p_name','$p_longitude','$p_latitude')";
     
    if(mysqli_query($con, $statement)){
	echo '���ε�';
    } else{
	echo '���ε� ����';
    }
?>